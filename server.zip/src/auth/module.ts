import { Module } from '@nestjs/common';
import { AuthService } from './service';
import { UserModule } from 'src/table/user/user.module';
import { JwtModule } from '@nestjs/jwt';
import { AuthController } from './controller';
import { jwtConstants } from './constants';

import { UserService } from 'src/table/user/user.service';
import { KabupatenService } from 'src/table/kabupaten/kabupaten.service';
import { ProvinsiService } from 'src/table/provinsi/provinsi.service';

import { KategorisumberService } from 'src/table/kategorisumber/kategorisumber.service';
import { SubsumberService } from 'src/table/subsumber/subsumber.service';
import { SetoranService } from 'src/table/setoran/setoran.service';

@Module({
  imports: [
    UserModule,
    JwtModule.register({
      global: true,
      secret: jwtConstants.secret,
      signOptions: { expiresIn: '1h' },
    }),
  ],
  providers: [AuthService, UserService,KabupatenService,ProvinsiService,KategorisumberService,
    SubsumberService,SetoranService,
  ],
  controllers: [AuthController],
  exports: [AuthService,KabupatenService,ProvinsiService,KategorisumberService,
    SubsumberService,SetoranService,
  ],
})
export class AuthModule {}