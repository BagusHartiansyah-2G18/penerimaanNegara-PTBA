import { Body, Controller, Post,Get,  HttpCode, HttpStatus, UseGuards, Request } from '@nestjs/common';
import { AuthService } from './service';

import { UserService } from 'src/table/user/user.service';
import { UserCreate } from 'src/table/user/user.create';
import { ProvinsiService } from 'src/table/provinsi/provinsi.service';
import { ProvinsiCreate } from 'src/table/provinsi/provinsi.create';
import { KabupatenService } from 'src/table/kabupaten/kabupaten.service';
import { KabupatenCreate } from 'src/table/kabupaten/kabupaten.create';

import { KategorisumberService } from 'src/table/kategorisumber/kategorisumber.service';
import { SubSumberCreate } from 'src/table/subsumber/subsumber.create';
import { SubsumberService } from 'src/table/subsumber/subsumber.service'; 

import { SetoranService } from 'src/table/setoran/setoran.service';
import { setoranCreate } from 'src/table/setoran/setoran.create';

import { AuthGuard } from './authGuard'; 
 
@Controller('auth')  
export class AuthController {
  constructor(
    private authService: AuthService,
    private user:UserService,
    private prov:ProvinsiService,
    private kab:KabupatenService,
    private kategori:KategorisumberService,
    private sub:SubsumberService,
    private setor:SetoranService,
  ) {}

  @HttpCode(HttpStatus.OK)
  @Post('login')
  signIn(@Body() signInDto: Record<string, any>) {
    return this.authService.signIn(signInDto.username, signInDto.password);
  }

  

  @UseGuards(AuthGuard)
  @Get('getuser')
  __user(@Request() req) {  
    const { kdRA,kdUser } = req.user; 
    if(kdRA==1){
      return  this.user.__user()
    }else{
      return this.user.findOne(kdUser)
    } 
  }
  
  @UseGuards(AuthGuard)
  @Post('setuser')
  async _user(@Body() duser: UserCreate,@Request() req) { 
    await this.user._user(duser);
    const { kdRA,kdUser } = req.user; 
    if(kdRA==1){
      return  this.user.__user()
    }else{
      return this.user.findOne(kdUser)
    } 
    
  }

  @UseGuards(AuthGuard)
  @Post('updPengguna')
  async updPengguna(@Request() req , @Body() duser: Record<string, any>) {  
    await this.user.updUser(duser);   
    const { kdRA,kdUser } = req.user; 
    if(kdRA==1){
      return  this.user.__user()
    }else{  
      return this.user.findOne(kdUser)
    } 
  }
  
  @Post('delPengguna')
  delPengguna(@Body() duser: Record<string, any> ) { 
    return this.user.delUser(duser);  
  }
  


  //batas
  @Get('getProvinsi')
  getProvinsi(@Request() req) {  
    return this.prov.__provinsi();
  }

  //batas 
  @Post('setkab')
  setkab(@Body() dval: KabupatenCreate) {  
    return this.kab._Kabupaten(dval);
  }
  @Post('updkab')
  updkab(@Body() dval: KabupatenCreate) {  
    return this.kab.updKab(dval);
  }
  @Post('delKab')
  delKab(@Body() dval: Record<string, any>) {  
    return this.kab.delKab(dval);
  }
  

  //batas
  @Get('getKategori')
  getKategori(@Request() req) {  
    return this.kategori.__();
  }
  
  //batas 
  @Post('setsubSumber')
  setsubSumber(@Body() dval: SubSumberCreate) {  
    return this.sub._(dval);
  }
  
  @Get('getSubSumber')
  getSubSumber(@Request() req) {  
    return this.sub.__();
  }
  @Post('updsubSumber')
  updsubSumber(@Body() dval: KabupatenCreate) {  
    return this.sub.upd(dval);
  }
  @Post('delsubSumber')
  delsubSumber(@Body() dval: Record<string, any>) {   
    return this.sub.del(dval);
  }
  

  //setsetor
  @UseGuards(AuthGuard)
  @Post('setsetor')
  async setsetor(@Request() req ,@Body() dval: setoranCreate) {   
    await this.setor._(dval);
    const { kdRA,kdUser } = req.user; 
    if(kdRA==1){
      return  this.setor.__('');
    }else{  
      return this.setor.__(kdUser);
    } 
  }

  @UseGuards(AuthGuard)
  @Get('getsetor')
  async getsetor(@Request() req ) {   
    const { kdRA,kdUser } = req.user; 
    if(kdRA==1){
      return await this.setor.__('');
    }else{ 
      return await this.setor.__(kdUser);    
    }  
  }

  @UseGuards(AuthGuard)
  @Post('updsetor')
  async updsetor(@Request() req ,@Body() dval: setoranCreate) { 
    const { kdRA,kdUser } = req.user; 
    await this.setor.upd(dval);
    if(kdRA==1){
      return  this.setor.__('')
    }else{ 
      return await this.setor.__(kdUser);    
      
    }   
    
  }

  @Post('delsetor')
  delsetor(@Body() dval: Record<string, any>) {   
    return this.setor.del(dval);
  }
  
}