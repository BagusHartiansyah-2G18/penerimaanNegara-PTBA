import { Injectable, UnauthorizedException } from '@nestjs/common';
import { UserService } from 'src/table/user/user.service';
import { JwtService } from '@nestjs/jwt';

 
@Injectable()
export class AuthService {
  constructor(
    private usersService: UserService,
    private jwtService: JwtService
  ) {} 
  async signIn(
    xusername: string,
    xpass: string,
  ): Promise<{ access_token: string }> { 
    const user = await this.usersService.findUserLogin(xusername);   
    const { username, pass, kdKab, kdProv, kdUser, kdRA } = user.filter(v=>v.username == xusername && v.pass == xpass)[0]; 
    // console.log(kdRA);
    
    if (pass !== xpass) {
      throw new UnauthorizedException();
    }
    const payload = { kdProv,kdKab, username, kdRA, kdUser};
    return {
      access_token: await this.jwtService.signAsync(payload),
    };
  }
}