import { Module } from '@nestjs/common';  
import { DataSource } from 'typeorm';

 import { KabupatenService } from './table/kabupaten/kabupaten.service';
 import { RoleController } from './table/role/role.controller';
import { RoleService } from './table/role/role.service'; 
import { KabupatenController } from './table/kabupaten/kabupaten.controller';  

import { AppController } from './app.controller';
import { UserService } from './table/user/user.service';
import { ProvinsiService } from './table/provinsi/provinsi.service'; 
import { UserController } from './table/user/user.controller';
import { ProvinsiController } from './table/provinsi/provinsi.controller'; 
import { AppService } from './app.service';

import { TypeOrmModules } from './table/datasource/typeorm.module';
import { AuthModule } from './auth/module';
import { AuthController } from './auth/controller';
import { AuthService } from './auth/service';

import { SubsumberController } from './table/subsumber/subsumber.controller';
import { SubsumberModule } from './table/subsumber/subsumber.module';

import { KategorisumberController } from './table/kategorisumber/kategorisumber.controller';
import { KategorisumberModule } from './table/kategorisumber/kategorisumber.module';
import { SubsumberService } from './table/subsumber/subsumber.service';
import { KategorisumberService } from './table/kategorisumber/kategorisumber.service';
import { SetoranService } from './table/setoran/setoran.service';

 
@Module({
  // imports: [
    // TypeOrmModule.forRoot({
    //   type: 'mssql',
    //   host: 'localhost',
    //   port: 1433,
    //   username: 'sa',
    //   password: '@gustus1997Aa',
    //   database: 'note',
    //   options: {
    //     encrypt: false, // MSSQL-specific option
    //   },
    //   synchronize: true, //use this with development environment
    //   // entities: [Note],
    //   entities: [__dirname + '/**/*.entity{.ts,.js}'],
    // }),
  //   // TypeOrmModules
    
  //   // ProvinsiModule,
  //   // KabupatenModule,
  //   // KecamatanModule,
  //   // RoleModule, 
  //   // UserModule,  
  //   // TypeOrmModule
  // ], 
  // providers:[AppService],
  // controllers:[AppController], 
  // providers: [KabupatenService, RoleService, UserService, ProvinsiService, KecamatanService, AppService ],
  // controllers: [KabupatenController, RoleController, UserController, ProvinsiController, KecamatanController,AppController ],
  
  imports:[TypeOrmModules, AuthModule, KategorisumberModule, SubsumberModule, KategorisumberModule, 
    SubsumberModule
  ],
  controllers:[
    AppController, UserController, ProvinsiController,
    KabupatenController, RoleController, AuthController, SubsumberController,KategorisumberController,
    SubsumberController,
  ],
  providers: [
    AppService, UserService, ProvinsiService, SubsumberService,
    KabupatenService, RoleService, AuthService, KategorisumberService, SetoranService
  ],

})
export class AppModule {
  private dataSource: DataSource
}