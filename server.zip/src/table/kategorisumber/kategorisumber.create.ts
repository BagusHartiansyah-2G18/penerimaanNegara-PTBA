import { IsNotEmpty, IsInt } from 'class-validator';

export class RoleCreate {
  @IsNotEmpty({ message: 'Kode kategori Sumber cannot be empty' })
  kdKS: string;

  @IsNotEmpty({ message: 'nama kategori Sumber cannot be empty' })
  nmKS: string; 

  @IsNotEmpty({ message: 'Kode Real kategori Sumber  cannot be empty' })
  realKS: string;

  @IsNotEmpty({ message: 'Real kategori Sumber cannot be empty' })
  realKSKet: string; 
}