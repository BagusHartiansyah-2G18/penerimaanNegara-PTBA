import { Controller } from '@nestjs/common';

@Controller('kategorisumber')
export class KategorisumberController {}
