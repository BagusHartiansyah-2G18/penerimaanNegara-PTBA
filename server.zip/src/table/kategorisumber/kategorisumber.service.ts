 import { Injectable,
    HttpException,
    HttpStatus, 
    InternalServerErrorException,
    Logger,
} from '@nestjs/common';
import { DataSource } from 'typeorm';

import { KategoriSumber } from './kategorisumber.entity';
import { KabupatenCreate } from '../kabupaten/kabupaten.create';

@Injectable()
export class KategorisumberService {
    private frepository;
    private logger = new Logger();

    constructor(private dataSource: DataSource) {  
        this.dataSource.createQueryRunner();
        this.frepository = this.dataSource.getRepository(KategoriSumber);
    }

    async __(): Promise<KategoriSumber[]> { //get   
        return this.frepository.find();
    }
}
