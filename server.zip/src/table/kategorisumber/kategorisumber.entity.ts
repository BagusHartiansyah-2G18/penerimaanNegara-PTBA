import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
@Entity('KategoriSumber')
export class KategoriSumber { 
    @PrimaryColumn({name: 'kdKS', length: 5, nullable: false})
    kdKS : string; 

    @Column({ name: 'nmKS', length: 150, nullable: false })
    nmKS: string;
    
    @Column({name: 'realKS', length: 5, nullable: false})
    realKS : string;

    @Column({name: 'realKSKet', length: 100, nullable: false})
    realKSKet : string;
}