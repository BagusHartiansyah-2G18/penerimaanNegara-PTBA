import { Module } from '@nestjs/common';
import { KategorisumberService } from './kategorisumber.service';
import { KategorisumberController } from './kategorisumber.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { KategoriSumber } from './kategorisumber.entity';

@Module({
  imports: [TypeOrmModule.forFeature([KategoriSumber])],  
  providers: [KategorisumberService],
  controllers: [KategorisumberController]
})
export class KategorisumberModule {}
