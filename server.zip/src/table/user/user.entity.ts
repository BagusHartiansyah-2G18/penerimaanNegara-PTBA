import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
@Entity('user')
export class User {
    @PrimaryColumn({name: 'kdUser', length: 5, nullable: false})
    kdUser: string;

    @PrimaryColumn({name: 'kdRA', length: 5, nullable: false})
    kdRA : string;
    
    @PrimaryColumn({name: 'kdProv', length: 5, nullable: false})
    kdProv: string;

    @PrimaryColumn({name: 'kdKab', length: 5, nullable: false})
    kdKab: string;

    @PrimaryColumn({name: 'kdKec ', length: 5, nullable: false})
    kdKec: string;
  
    @Column({ name: 'nama', length: 100, nullable: false })
    nama: string;
  
    @Column({ name: 'username', length: 10, nullable: false })
    username : string;
  
    @Column({ name: 'pass', length: 100, nullable: true })
    pass: string;
}