import { Body, Controller, Delete, Get, Param, Post,Put } from '@nestjs/common';

import { UserService } from './user.service';
import { UserCreate } from './user.create';
import { User } from './user.entity';

@Controller('user/')
export class UserController {
    constructor(private readonly notesService: UserService) {}

    @Get()
    getNotes() {  
        return  this.notesService.__user();
    }

    // @Post()
    // createNote(@Body() createNoteDto: UserCreate): Promise<User> { 
    //     return this.notesService._user(createNoteDto);
    // }
}
