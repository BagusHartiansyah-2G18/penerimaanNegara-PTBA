import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

import {
    HttpException,
    HttpStatus, 
    InternalServerErrorException,
    Logger,
  } from '@nestjs/common';

import { UserCreate } from './user.create';
import { User } from './user.entity';
    
@Injectable()
export class UserService  {  
    private userRepository;
    private logger = new Logger();

    constructor(private dataSource: DataSource) {  
        this.dataSource.createQueryRunner();
        this.userRepository = this.dataSource.getRepository(User);
    }

    async __user(): Promise<User[]> { //get   
      return this.dataSource.query(`
        select a.*,b.nmKab,c.nmProv  from 
        [note].[dbo].[user] a 
        join [note].[dbo].[kabupaten] b on
          a.kdKab = b.kdKab
        join [note].[dbo].[provinsi] c  on
          a.kdProv= c.kdProv 
      `);
        // return this.userRepository.find();
    }
    async _user(createUser: UserCreate): Promise<User[]> {    
      const cuser =(await this.__user());  
      if(cuser.filter(v=>v.username==createUser.username).length>0){ 
        throw new HttpException('Username already exists', HttpStatus.CONFLICT);
      } 
      const fdt =(await this.__kdUser(createUser));  
      createUser.kdUser = '1';
      if(fdt.length){
        createUser.kdUser =String( Number(fdt[0].kdUser)+1);
      }  
      
      try {
          const xuser = await this.userRepository.create({...createUser}); 
          return this.userRepository.save(xuser); 
      } catch (err) {
        if (err.code == 23505) {
          this.logger.error(err.message, err.stack);
          throw new HttpException('Username already exists', HttpStatus.CONFLICT);
        }
        this.logger.error(err.message, err.stack);
        throw new InternalServerErrorException(
          'Something went wrong, Try again!',
        );
      }
    }
    async findOne(kdUser: string): Promise<User[] | undefined> {
      return this.dataSource.query(`
          select a.*,b.nmKab,c.nmProv  from 
          [note].[dbo].[user] a 
          join [note].[dbo].[kabupaten] b on
            a.kdKab = b.kdKab
          join [note].[dbo].[provinsi] c  on
            a.kdProv= c.kdProv 
          where  a.kdUser='${kdUser}'
        `);
 
      // this.userRepository.find(user => user.kdUser === kdUser);
    }
    async findUserLogin(username: string): Promise<User[] | undefined> {
      return this.userRepository.find(user => user.username == username);
    }
    async __kdUser(p: UserCreate): Promise<User[] | undefined> {
      // return this.userRepository.query(user => user.kdRA === createUser.kdRA)
      return this.dataSource.query("select kdUser from [note].[dbo].[user]  order by CAST(kdUser as int) desc")
    }
    async updUser(v: Record<string, any>) {  
      return await this.userRepository.update(
        {
          kdUser:v.kdUser, 
        },{ 
          nama:v.nama,
          username:v.username,
          pass:v.pass,
          kdProv:v.kdProv,
          kdKab:v.kdKab,
          kdRA:v.kdRA
        }
      );   
      // return this.__user();
    }
    async delUser(v: Record<string, any>) {  
      return this.userRepository.delete(
        {
          kdUser:v.kdUser
        } );   
    }
}
