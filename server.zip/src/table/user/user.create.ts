import { IsNotEmpty, IsInt } from 'class-validator';

export class UserCreate {
  @IsNotEmpty({ message: 'kode Member field cannot be empty' })
  kdUser: string;

  @IsNotEmpty({ message: 'Jabatan cannot be empty' })
  kdRA: string;

  @IsNotEmpty({ message: 'Provinsi  cannot be empty' })
  // @IsInt({ message: 'rating must be of type number' })
  kdProv: string;

  @IsNotEmpty({ message: 'Kabupaten cannot be empty' })
  kdKab: string;

  @IsNotEmpty({ message: 'kecamatan cannot be empty' })
  kdKec: string;

  @IsNotEmpty({ message: 'nama cannot be empty' })
  nama: string;

  @IsNotEmpty({ message: 'username cannot be empty' })
  username: string;

  @IsNotEmpty({ message: 'Password cannot be empty and len 10' })
  pass: string;
}