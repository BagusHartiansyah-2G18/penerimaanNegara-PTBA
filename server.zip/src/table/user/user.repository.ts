import { Repository } from 'typeorm';
import { User } from './user.entity'; 
import { InjectRepository } from '@nestjs/typeorm';
export class UserRepository extends Repository<User> {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
  ) {
    super(
      userRepository.target,
      userRepository.manager,
      userRepository.queryRunner,
    );
  }

  public async findAll(): Promise<User[]> {
    return this.find();
  }

  public async findById(id: number): Promise<User | null> {
    return;
    // return this.findOneBy({ id: id });
  } 
  public async destroy(id: number): Promise<void> {
    await this.delete(id);
  }
}