import { Controller } from '@nestjs/common';

@Controller('kecamatan')
export class KecamatanController {}
