import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
@Entity('kecamatan')
export class Kecamatan { 
    @PrimaryColumn({name: 'kdProv', length: 5, nullable: false})
    kdProv: string;

    @PrimaryColumn({name: 'kdKab', length: 5, nullable: false})
    kdKab: string;

    @PrimaryColumn({name: 'kdKec ', length: 5, nullable: false})
    kdKec: string;
  
    @Column({ name: 'nmKec', length: 150, nullable: false })
    nmKec: string;
   
}