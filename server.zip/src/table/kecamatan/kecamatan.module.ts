import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { KecamatanController } from './kecamatan.controller';
import { KecamatanService } from './kecamatan.service';

import { Kecamatan } from './kecamatan.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Kecamatan])], 
  controllers: [KecamatanController],
  providers: [KecamatanService]
})
export class KecamatanModule {}
