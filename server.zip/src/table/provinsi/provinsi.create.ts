import { IsNotEmpty, IsInt } from 'class-validator';

export class ProvinsiCreate {
  @IsNotEmpty({ message: 'Provinsi  cannot be empty' })
   kdProv: string;

  @IsNotEmpty({ message: 'nama Provinsi cannot be empty' })
  nmProv: string; 
}