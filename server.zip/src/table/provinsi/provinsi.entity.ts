import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
@Entity('provinsi')
export class Provinsi { 
    @PrimaryColumn({name: 'kdProv', length: 5, nullable: false})
    kdProv: string; 
    @Column({ name: 'nmProv', length: 150, nullable: false })
    nmProv: string;
   
}