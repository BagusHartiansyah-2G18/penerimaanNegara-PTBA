import { Body, Controller, Delete, Get, Param, Post,Put } from '@nestjs/common';
import { ProvinsiService } from './provinsi.service';
import { ProvinsiCreate } from './provinsi.create';
import { Provinsi } from './provinsi.entity';

@Controller('provinsi')
export class ProvinsiController {
    constructor(private readonly fservice: ProvinsiService) {}

    @Get()
    getNotes() { 
        return this.fservice.__provinsi();
    }

    @Post()
    createNote(@Body() fparam: ProvinsiCreate): Promise<Provinsi> { 
        return this.fservice._provinsi(fparam);
    }

}
