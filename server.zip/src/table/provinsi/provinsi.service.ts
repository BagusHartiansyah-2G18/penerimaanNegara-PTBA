import { Injectable,
    HttpException,
    HttpStatus, 
    InternalServerErrorException,
    Logger,
} from '@nestjs/common';
import { DataSource } from 'typeorm';


import { ProvinsiCreate } from './provinsi.create';
import { Provinsi } from './provinsi.entity';



@Injectable()
export class ProvinsiService {
    private frepository;
    private logger = new Logger();

    constructor(private dataSource: DataSource) {  
        this.dataSource.createQueryRunner();
        this.frepository = this.dataSource.getRepository(Provinsi);
    }

    async __provinsi(): Promise<Provinsi[]> { //get   
        return this.frepository.find();
    }
    async _provinsi(fparam: ProvinsiCreate): Promise<Provinsi> {   
      try {
          const xrepo = await this.frepository.create({...fparam}); 
          return await this.frepository.save(xrepo);
      } catch (err) {
        if (err.code == 23505) {
          this.logger.error(err.message, err.stack);
          throw new HttpException('Username already exists', HttpStatus.CONFLICT);
        }
        this.logger.error(err.message, err.stack);
        throw new InternalServerErrorException(
          'Something went wrong, Try again!',
        );
      }
    }
}
