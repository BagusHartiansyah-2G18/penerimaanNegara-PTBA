import { IsNotEmpty, IsInt } from 'class-validator';

export class RoleCreate {
  @IsNotEmpty({ message: 'Kode Role Access  cannot be empty' })
   kdRA: string;

  @IsNotEmpty({ message: 'nama Role Access cannot be empty' })
  nmRA: string; 
}