import { Injectable,
    HttpException,
    HttpStatus, 
    InternalServerErrorException,
    Logger,
} from '@nestjs/common';
import { DataSource } from 'typeorm';
import { RoleCreate } from './role.create';
import { Role } from './role.entity';




@Injectable()
export class RoleService {
    private frepository;
    private logger = new Logger();

    constructor(private dataSource: DataSource) {  
        this.dataSource.createQueryRunner();
        this.frepository = this.dataSource.getRepository(Role);
    }

    async __role(): Promise<Role[]> { //get   
        return this.frepository.find();
    }
    async _role(fparam: RoleCreate): Promise<Role> {   
      try {
          const xrepo = await this.frepository.create({...fparam}); 
          return await this.frepository.save(xrepo);
      } catch (err) {
        if (err.code == 23505) {
          this.logger.error(err.message, err.stack);
          throw new HttpException('Username already exists', HttpStatus.CONFLICT);
        }
        this.logger.error(err.message, err.stack);
        throw new InternalServerErrorException(
          'Something went wrong, Try again!',
        );
      }
    }
}
