import { Body, Controller, Delete, Get, Param, Post,Put } from '@nestjs/common';

import { Role } from './role.entity';
import { RoleService } from './role.service';
import { RoleCreate } from './role.create';

@Controller('role')
export class RoleController {
    constructor(private readonly fservice: RoleService) {}

    @Get()
    getNotes() { 
        return this.fservice.__role();
    }

    @Post()
    createNote(@Body() fparam: RoleCreate): Promise<Role> { 
        return this.fservice._role(fparam);
    }
}
