import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
@Entity('role')
export class Role { 
    @PrimaryColumn({name: 'kdRA', length: 5, nullable: false})
    kdRA : string; 

    @Column({ name: 'nmRA', length: 150, nullable: false })
    nmRA: string; 
}