import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
@Entity('kabupaten')
export class Kabupaten { 
    @PrimaryColumn({name: 'kdProv', length: 5, nullable: false})
    kdProv: string;

    @PrimaryColumn({name: 'kdKab', length: 5, nullable: false})
    kdKab: string; 

    @Column({ name: 'nmKab', length: 150, nullable: false })
    nmKab: string; 
}