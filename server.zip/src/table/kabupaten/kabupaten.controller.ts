import { Body, Controller, Delete, Get, Param, Post,Put } from '@nestjs/common';

import { Kabupaten } from './kabupaten.entity';
import { KabupatenCreate } from './kabupaten.create';
import { KabupatenService } from './kabupaten.service';


@Controller('kabupaten')
export class KabupatenController {
    constructor(private readonly fservice: KabupatenService) {}

    @Get()
    getNotes() { 
        return this.fservice.__Kabupaten();
    }

    @Post()
    createNote(@Body() fparam: KabupatenCreate): Promise<Kabupaten[]> { 
        return this.fservice._Kabupaten(fparam);
    }

}
