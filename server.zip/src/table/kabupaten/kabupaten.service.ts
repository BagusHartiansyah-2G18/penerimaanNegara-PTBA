import { Injectable,
    HttpException,
    HttpStatus, 
    InternalServerErrorException,
    Logger,
} from '@nestjs/common';
import { DataSource } from 'typeorm';

import { KabupatenCreate } from './kabupaten.create';
import { Kabupaten } from './kabupaten.entity';

@Injectable()
export class KabupatenService {
    private frepository;
    private logger = new Logger();

    constructor(private dataSource: DataSource) {  
        this.dataSource.createQueryRunner();
        this.frepository = this.dataSource.getRepository(Kabupaten);
    }

    async __Kabupaten(): Promise<Kabupaten[]> { //get   
        // return this.frepository.find();
        return this.dataSource.query(`
          select a.*,b.nmProv  from 
          [note].[dbo].[kabupaten] a 
          join [note].[dbo].[provinsi] b on
            a.kdProv = b.kdProv 
        `);
    }
    async _Kabupaten(fparam: KabupatenCreate): Promise<Kabupaten[]> {  
        const fdt =(await this.__kdKab(fparam));  
        fparam.kdKab = '1';
        if(fdt.length){
          fparam.kdKab =String( Number(fdt[0].kdKab)+1);
        }   
        try {
            const xrepo = await this.frepository.create({...fparam}); 
            await this.frepository.save(xrepo);
            return this.__Kabupaten();
        } catch (err) {
          if (err.code == 23505) {
            this.logger.error(err.message, err.stack);
            throw new HttpException('Username already exists', HttpStatus.CONFLICT);
          }
          this.logger.error(err.message, err.stack);
          throw new InternalServerErrorException(
            'Something went wrong, Try again!',
          );
        }
    }
    async __kdKab(p: KabupatenCreate): Promise<Kabupaten[] | undefined> {
      return this.dataSource.query("select kdKab from [note].[dbo].[kabupaten] where kdProv='"+p.kdProv+"' order by CAST(kdKab as int) desc")
    }
    async updKab(v: Record<string, any>) {  
      await this.frepository.update(
        {
          kdKab:v.xkdKab,
          kdProv:v.xkdProv 
        },{ 
          kdProv:v.kdProv,
          kdKab:v.kdKab, 
          nmKab:v.nmKab, 
        }
      );  
      return this.__Kabupaten(); 
    }
    async delKab(v: Record<string, any>) {  
      return this.frepository.delete(
        {
          kdKab:v.xkdKab,
          kdProv:v.xkdProv 
        } );   
    }
}
