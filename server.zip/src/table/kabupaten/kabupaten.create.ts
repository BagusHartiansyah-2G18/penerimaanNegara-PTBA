import { IsNotEmpty, IsInt } from 'class-validator';
export class KabupatenCreate {
  @IsNotEmpty({ message: 'Provinsi  cannot be empty' })
  // @IsInt({ message: 'rating must be of type number' })
  kdProv: string;

  @IsNotEmpty({ message: 'Kode Kabupaten cannot be empty' })
  kdKab: string;

  @IsNotEmpty({ message: 'nama Kabupaten cannot be empty' })
  nmKab: string;

}