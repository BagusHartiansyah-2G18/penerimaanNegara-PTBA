import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { KabupatenController } from './kabupaten.controller';
import { KecamatanService } from '../kecamatan/kecamatan.service';
import { Kecamatan } from '../kecamatan/kecamatan.entity';

@Module({
    imports: [TypeOrmModule.forFeature([Kecamatan])], 
    providers: [KecamatanService],
    controllers: [KabupatenController]
})
export class KabupatenModule {

}
