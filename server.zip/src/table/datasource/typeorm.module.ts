import { DataSource } from 'typeorm';
import { Global, Module } from '@nestjs/common';
import { User } from '../user/user.entity';
import { Provinsi } from '../provinsi/provinsi.entity';
import { Kabupaten } from '../kabupaten/kabupaten.entity';
import { Role } from '../role/role.entity';
import { SubSumber } from '../subsumber/subsumber.entity';
import { KategoriSumber } from '../kategorisumber/kategorisumber.entity';
import { setoran } from '../setoran/setoran.entity';

@Global() // makes the module available globally for other modules once imported in the app modules
@Module({
  imports: [],
  providers: [
    {
      provide: DataSource, // add the datasource as a provider
      inject: [],
      useFactory: async () => {
        // using the factory function to create the datasource instance
        // try {
        //   const dataSource = new DataSource({
        //     type: 'postgres',
        //     host: 'localhost',
        //     port: 5432,
        //     username: 'ayo',
        //     password: 'haywon',
        //     database: 'simple-crm_db',
        //     synchronize: true,
        //     entities: [`${__dirname}/../**/**.entity{.ts,.js}`], // this will automatically load all entity file in the src folder
        //   });
        //   await dataSource.initialize(); // initialize the data source
        //   console.log('Database connected successfully');
        //   return dataSource;
        // } catch (error) {
        //   console.log('Error connecting to database');
        //   throw error;
        // }


        try {
          const dataSource = new DataSource({
            type: 'mssql',
            host: 'localhost',
            port: 1433,
            username: 'sa',
            password: '@gustus1997Aa',
            database: 'note',
            options: {
              encrypt: false, // MSSQL-specific option
            },
            synchronize: true, //use this with development environment
            entities: [User,Provinsi,Kabupaten,Role,SubSumber,KategoriSumber,setoran],
            // entities: [__dirname + '/**/*.entity{.ts,.js}'],
            // logging: true,

          });
          await dataSource.initialize(); // initialize the data source
          // console.log('Database connected successfully');
          return dataSource;
        } catch (error) {
          // console.log('Error connecting to database');
          throw error;
        } 

      },
    },
  ],
  exports: [DataSource],
})
export class TypeOrmModules {}
