import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';
import {
    HttpException,
    HttpStatus, 
    InternalServerErrorException,
    Logger,
} from '@nestjs/common';

import { setoranCreate } from './setoran.create';
import { setoran } from './setoran.entity';

@Injectable()
export class SetoranService {
    private frepository;
    private logger = new Logger();

    constructor(private dataSource: DataSource) {  
        this.dataSource.createQueryRunner();
        this.frepository = this.dataSource.getRepository(setoran);
    }

    async __(kdUser:string): Promise<setoran[]> { //get   
        // return this.frepository.find();
        // ((CAST(a.totol as int)* CAST(c.kabP as int))/100) as kabP, ((CAST(a.totol as int)* CAST(c.provP as int))/100) as provP, 
        //         ((CAST(a.totol as int)* CAST(c.pusatP as int))/100) as pusatP,
        let xkdUser = '';
        if(kdUser!==''){
          xkdUser=` where b.kdUser='${kdUser}'`;
        } 
        return await this.dataSource.query(`
            select a.kdSetoran,a.dateS,a.totol as total,
                b.kdUser,b.kdProv,b.kdKab, b.kdRA, b.nama,
                c.nmSS, c.kdKS, c.kdSS, c.kabP,c.provP,c.pusatP, 
                d.nmKS,d.realKSKet,
                e.nmKab,
                f.nmProv 
            from [note].[dbo].[setoran] a 
            join [note].[dbo].[user] b on
              a.kdUser = b.kdUser
            join [note].[dbo].[SubSumber] c on
                a.kdSS =concat(c.kdKS,'|',c.kdSS)
            join [note].[dbo].[KategoriSumber] d on
                c.kdKS = d.kdKS
            join [note].[dbo].[kabupaten] e on
                b.kdKab =e.kdKab
            join [note].[dbo].[provinsi] f on
                b.kdProv = f.kdProv
            ${xkdUser}
        `);
    } 
    async _(fparam: setoran): Promise<setoran[]> { //set   
        const fdt =(await this.__kdSetoran(fparam));  
        fparam.kdSetoran = '1';
        if(fdt.length){
          fparam.kdSetoran =String( Number(fdt[0].kdSetoran)+1);
        }   
        fparam.dateE='-';
        try {
            const xrepo = await this.frepository.create({...fparam}); 
            return await this.frepository.save(xrepo); 
        } catch (err) { 
          this.logger.error(err.message, err.stack);
          throw new InternalServerErrorException(
            'Something went wrong, Try again!',
          );
        }
    }
    async __kdSetoran(p: setoran): Promise<setoran[] | undefined> {
        return this.dataSource.query("select kdSetoran from [note].[dbo].[setoran] where kdUser='"+p.kdUser+"'  order by CAST(kdSetoran as int) desc")
    }
    async upd(v: Record<string, any>) {  
      return await this.frepository.update(
        {
          kdSetoran:v.kdSetoran,
          kdUser:v.kdUser
        },{ 
          kdSS:v.kdSS,
          dateE:v.dateE, 
          totol:v.totol,
        }
      );  
    }
    async del(v: Record<string, any>) {  
      return this.frepository.delete(
        {
          kdSetoran:v.kdSetoran,
          kdUser:v.kdUser
        });   
    }
}   
