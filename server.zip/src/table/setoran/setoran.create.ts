import { IsNotEmpty, IsInt } from 'class-validator';

export class setoranCreate {
  @IsNotEmpty({ message: 'Index Setoran  cannot be empty' })
  kdSetoran: string;

  @IsNotEmpty({ message: 'Sub Sumber cannot be empty' })
  kdSS: string; 

  @IsNotEmpty({ message: 'User  cannot be empty' })
  kdUser: string;

  @IsNotEmpty({ message: 'date Start cannot be empty' })
  dateS: string; 

  @IsNotEmpty({ message: 'date Update cannot be empty' })
  dateE: string;

  @IsNotEmpty({ message: 'Total cannot be empty' })
  totol: string; 
}