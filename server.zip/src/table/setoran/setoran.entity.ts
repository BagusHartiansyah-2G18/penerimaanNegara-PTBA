import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
@Entity('setoran')
export class setoran { 
    @PrimaryColumn({name: 'kdSetoran', length: 5, nullable: false})
    kdSetoran : string; 
    
    @Column({name: 'kdSS', length: 50, nullable: false})
    kdSS : string; 

    @PrimaryColumn({ name: 'kdUser', length: 50, nullable: false })
    kdUser: string; 

    @Column({ name: 'dateS', length: 15, nullable: false })
    dateS: string; 

    @Column({ name: 'dateE', length: 15, nullable: false })
    dateE: string; 

    @Column({ name: 'totol', length: 40, nullable: false })
    totol: string; 
 
}