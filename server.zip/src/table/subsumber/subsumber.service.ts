import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

import {
    HttpException,
    HttpStatus, 
    InternalServerErrorException,
    Logger,
} from '@nestjs/common';

import { SubSumberCreate } from './subsumber.create';
import { SubSumber } from './subsumber.entity';

@Injectable()
export class SubsumberService {
    private frepository;
    private logger = new Logger();

    constructor(private dataSource: DataSource) {  
        this.dataSource.createQueryRunner();
        this.frepository = this.dataSource.getRepository(SubSumber);
    }
    async __(): Promise<SubSumberCreate[]> { //get   
        // return this.frepository.find();
        return this.dataSource.query(`
            select a.*,b.nmKS,b.realKSKet  from 
            [note].[dbo].[SubSumber] a 
            join [note].[dbo].[KategoriSumber] b on
              a.kdKS = b.kdKS 
        `);
    }
    async _(fparam: SubSumberCreate): Promise<SubSumberCreate[]> { //get   
        const fdt =(await this.__kdSS(fparam));  
        fparam.kdSS = '1';
        if(fdt.length){
          fparam.kdSS =String( Number(fdt[0].kdSS)+1);
        }   
        try {
            const xrepo = await this.frepository.create({...fparam}); 
            await this.frepository.save(xrepo);
            return this.__();
        } catch (err) { 
          this.logger.error(err.message, err.stack);
          throw new InternalServerErrorException(
            'Something went wrong, Try again!',
          );
        }
    }
    async __kdSS(p: SubSumberCreate): Promise<SubSumberCreate[] | undefined> {
        return this.dataSource.query("select kdSS from [note].[dbo].[SubSumber] where kdKS='"+p.kdKS+"' order by CAST(kdSS as int) desc")
    }
    async upd(v: Record<string, any>) {  
        await this.frepository.update(
          {
            kdKS:v.xkdKS,
            kdSS:v.xkdSS 
          },{ 
            nmSS:v.nmSS,
            kabP:v.kabP, 
            provP:v.provP, 
            pusatP:v.pusatP 
          }
        );  
        return this.__(); 
    }
    async del(v: Record<string, any>) {  
      return this.frepository.delete(
        {
          kdKS:v.kdKS,
          kdSS:v.kdSS 
        });   
    }
}
