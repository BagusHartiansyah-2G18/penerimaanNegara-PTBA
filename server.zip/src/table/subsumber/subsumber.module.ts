import { Module } from '@nestjs/common';
import { SubsumberService } from './subsumber.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SubSumber } from './subsumber.entity';
import { SubsumberController } from './subsumber.controller';

@Module({
  imports: [TypeOrmModule.forFeature([SubSumber])],
  providers: [SubsumberService],
  controllers: [SubsumberController]
})
export class SubsumberModule {}
