import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
@Entity('SubSumber')
export class SubSumber { 
    @PrimaryColumn({name: 'kdKS', length: 5, nullable: false})
    kdKS : string; 
    
    @PrimaryColumn({name: 'kdSS', length: 5, nullable: false})
    kdSS : string; 

    @Column({ name: 'nmSS', length: 150, nullable: false })
    nmSS: string; 

    @Column({ name: 'kabP', length: 5, nullable: false })
    kabP: string; 

    @Column({ name: 'provP', length: 5, nullable: false })
    provP: string; 

    @Column({ name: 'pusatP', length: 5, nullable: false })
    pusatP: string; 
}