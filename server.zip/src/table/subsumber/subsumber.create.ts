import { IsNotEmpty, IsInt } from 'class-validator';

export class SubSumberCreate {
  @IsNotEmpty({ message: 'Kode Kategori Sumber  cannot be empty' })
  kdKS: string;

  @IsNotEmpty({ message: 'kode Sub Sumber cannot be empty' })
  kdSS: string; 

  @IsNotEmpty({ message: 'Nama Sub Sumber  cannot be empty' })
  nmSS: string;

  @IsNotEmpty({ message: 'Persentase Kabupaten cannot be empty' })
  kabP: string; 

  @IsNotEmpty({ message: 'Persentase Provinsi cannot be empty' })
  provP: string;

  @IsNotEmpty({ message: 'Persentase Pusat cannot be empty' })
  pusatP: string; 
}