import { Repository } from 'typeorm';
import { SubSumber } from './subsumber.entity';
import { InjectRepository } from '@nestjs/typeorm';
export class UserRepository extends Repository<SubSumber> {
  constructor(
    @InjectRepository(SubSumber)
    private userRepository: Repository<SubSumber>,
  ) {
    super(
      userRepository.target,
      userRepository.manager,
      userRepository.queryRunner,
    );
  }

  // public async findAll(): Promise<User[]> {
  //   return this.find();
  // }

  // public async findById(id: number): Promise<User | null> {
  //   return;
  //   // return this.findOneBy({ id: id });
  // } 
  // public async destroy(id: number): Promise<void> {
  //   await this.delete(id);
  // }
}