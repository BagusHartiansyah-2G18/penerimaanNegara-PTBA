import { Controller } from '@nestjs/common';

@Controller('subsumber')
export class SubsumberController {}
